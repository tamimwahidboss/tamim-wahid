<?php
/**
 * Plugin Name
 *
 * @package           TWPackage
 * @author            Tamim Wahid
 * @copyright         2025 Tamim Wahid
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       TW External
 * Plugin URI:        https://example.com/plugin-name
 * Description:       This is a mandatory plugin for Tamim Wahid's WordPress Theme.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Tamim Wahid
 * Author URI:        https://wahid.wordpress10ms.com
 * Text Domain:       tw-external
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */




if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Custom post type for Portfolio
if ( ! function_exists( 'tw_custom_portfolio_post_type' ) ) {
    function tw_custom_portfolio_post_type () {
        $labels = array(
            'name'                  => __( 'Portfolios', 'tamim-wahid' ),
            'singular_name'         => __( 'Portfolio', 'tamim-wahid' ),
            'menu_name'             => __( 'Portfolio', 'tamim-wahid' ),
            'name_admin_bar'        => __( 'Portfolio', 'tamim-wahid' ),
            'add_new'               => __( 'Add New', 'tamim-wahid' ),
            'add_new_item'          => __( 'Add New Portfolio', 'tamim-wahid' ),
            'new_item'              => __( 'New portfolio', 'tamim-wahid' ),
            'edit_item'             => __( 'Edit portfolio', 'tamim-wahid' ),
            'view_item'             => __( 'View portfolio', 'tamim-wahid' ),
            'all_items'             => __( 'All portfolios', 'tamim-wahid' ),
            'search_items'          => __( 'Search portfolios', 'tamim-wahid' ),
            'parent_item_colon'     => __( 'Parent portfolios:', 'tamim-wahid' ),
            'not_found'             => __( 'No portfolios found.', 'tamim-wahid' ),
            'not_found_in_trash'    => __( 'No portfolios found in Trash.', 'tamim-wahid' ),
            'featured_image'        => __( 'Portfolio Cover Image', 'tamim-wahid' ),
            'set_featured_image'    => __( 'Set cover image', 'tamim-wahid' ),
            'remove_featured_image' => __( 'Remove cover image', 'tamim-wahid' ),
            'use_featured_image'    => __( 'Use as cover image', 'tamim-wahid' ),
            'archives'              => __( 'Portfolio archives', 'tamim-wahid' ),
            'insert_into_item'      => __( 'Insert into Portfolio', 'tamim-wahid' ),
            'uploaded_to_this_item' => __( 'Uploaded to this portfolio', 'tamim-wahid' ),
            'filter_items_list'     => __( 'Filter portfolios list', 'tamim-wahid' ),
            'items_list_navigation' => __( 'Portfolios list navigation', 'tamim-wahid' ),
            'items_list'            => __( 'Portfolios list', 'tamim-wahid' ),
        );

        $args = array(
            'labels'             => $labels,
            'description'        => 'Portfolio custom post type.',
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'portfolio' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 20,
            'menu_icon'          => 'dashicons-portfolio',
            'supports'           => array( 'title', 'thumbnail', 'editor'),
            'taxonomies'         => array( 'category', 'post_tag' ),
            'show_in_rest'       => true
        );
        
        register_post_type( 'portfolio', $args );
    }
    add_action( 'init', 'tw_custom_portfolio_post_type' );
}
